<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Evisas - Visa & Kitas Extention</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/alpinejs" defer></script>
  <link rel="icon" href="{{ asset('favicon.ico') }}" type="image/x-icon">
  <style>
    body {
    background-color: #000;
        
      font-family: 'Inter', sans-serif;
    }

    [x-cloak] {
      display: none !important;
    }
    
    html {
    scroll-behavior: smooth;
  }
  </style>
  
  <link rel="preload" as="image" href="/images/ocean-bali.webp" type="image/webp">

</head>


<body class="bg-white text-gray-800">
  <!-- Header -->
  <header class="bg-gradient-to-r from-sky-900 to-blue-700 shadow-lg sticky top-0 z-50 backdrop-blur-md"
        x-data="{ navOpen: false, serviceOpen: false, mobileServiceOpen: false }">
  <div class="max-w-7xl mx-auto flex justify-between items-center py-4 px-6 md:px-12">

    <!-- Logo -->
    <div class="flex items-center gap-3">
  <img src="{{ asset('icons/logo.webp') }}" alt="Evisas Icon" class="w-10 h-10">
  <img src="{{ asset('images/EVISAS WHITE1.png') }}" alt="Evisas Text" class="h-5 md:h-5">
  </div>

    <!-- Desktop Navigation -->
    <nav class="hidden md:flex items-center space-x-8 text-sm font-semibold">
      <a href="/" class="text-white hover:text-yellow-400 transition duration-200">Home</a>

      <!-- Dropdown -->
      <div @mouseenter="serviceOpen = true" @mouseleave="serviceOpen = false" class="relative">
        <button class="flex items-center gap-1 text-white hover:text-yellow-400 transition duration-200">
          Our Services
          <svg class="w-4 h-4 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path d="M19 9l-7 7-7-7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
          </svg>
        </button>
        <div x-show="serviceOpen" x-cloak x-transition
             class="absolute left-0 mt-3 w-64 bg-white text-gray-800 rounded-lg shadow-lg border border-blue-300 z-50 overflow-hidden">
          <a href="/landingpage/extention" class="block px-5 py-3 hover:bg-blue-100">Visa & Kitas Extension</a>
          <a href="/landingpage/kitas" class="block px-5 py-3 hover:bg-blue-100">KITAS</a>
          <a href="/landingpage/kitap" class="block px-5 py-3 hover:bg-blue-100">KITAP</a>
          <a href="/landingpage/visitorvisa" class="block px-5 py-3 hover:bg-blue-100">Visitor Visa</a>
          <a href="/landingpage/additional" class="block px-5 py-3 hover:bg-blue-100">Additional Immigration Services</a>
        </div>
      </div>

      <a href="/landingpage/companyprofile" class="text-white hover:text-yellow-400 transition duration-200">About Us</a>
    </nav>

    <!-- Mobile Nav Toggle -->
    <div class="md:hidden relative">
      <button @click="navOpen = !navOpen" class="text-white focus:outline-none transition">
        <svg x-show="!navOpen" class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2"
             viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16" stroke-linecap="round" stroke-linejoin="round"></path></svg>
        <svg x-show="navOpen" x-cloak class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2"
             viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" stroke-linecap="round" stroke-linejoin="round"></path></svg>
      </button>

      <!-- Mobile Menu -->
      <div x-show="navOpen" x-cloak x-transition
           class="absolute right-0 mt-3 w-64 bg-white text-gray-800 rounded-lg shadow-xl py-4 px-5 z-50 border border-blue-300 space-y-3 text-sm">
        <a href="/" class="block hover:text-yellow-500">Home</a>
        <div>
          <button @click="mobileServiceOpen = !mobileServiceOpen"
                  class="flex justify-between items-center w-full hover:text-yellow-500">
            Our Services
            <svg class="w-4 h-4 transform transition-transform duration-200"
                 :class="{ 'rotate-180': mobileServiceOpen }" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path d="M19 9l-7 7-7-7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
          </button>
          <div x-show="mobileServiceOpen" x-transition class="pl-4 mt-2 space-y-2">
            <a href="/landingpage/extention" class="block hover:text-yellow-500">Visa & Kitas Extension</a>
            <a href="/landingpage/kitas" class="block hover:text-yellow-500">KITAS</a>
            <a href="/landingpage/kitap" class="block hover:text-yellow-500">KITAP</a>
            <a href="/landingpage/visitorvisa" class="block hover:text-yellow-500">Visitor Visa</a>
            <a href="/landingpage/additional" class="block hover:text-yellow-500">Additional Immigration Services</a>
          </div>
        </div>
        <a href="/landingpage/companyprofile" class="block hover:text-yellow-500">About Us</a>
      </div>
    </div>
  </div>
</header>

<img src="{{ asset('images/ocean-bali.webp') }}" alt="Preload Background" class="hidden" loading="eager" fetchpriority="high">
<section class="py-20 px-6 bg-[url('/images/ocean-bali.webp')] bg-cover bg-center text-white relative mt-[-64px] min-h-[250px]">

  <!-- Overlay semi-transparan gelap -->
  <div class="absolute inset-0 bg-black/50"></div>

  <!-- Konten -->
  <div class="relative z-10 max-w-6xl mx-auto text-left pl-6">
  <h2 class="text-4xl md:text-5xl mt-16 mb-2">
    <span class="underline decoration-yellow-500 underline-offset-4">Visa & Kitas Extention</span>
  </h2>
</div>
</section>

<div class="bg-gradient-to-r from-sky-900 to-blue-700 shadow-lg sticky text-white text-sm px-4 py-3 md:px-20">
  <div class="max-w-7xl mx-auto pl-4 md:pl-20">
    <a href="/" class="hover:underline text-blue-600">Home</a> › 
    <span>Visa & Kitas Extention</span>
  </div>
</div>

<div class="bg-cover py-12 overflow-hidden" style="background-image: url('{{ asset('images/patternocean.svg') }}')">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-16">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">

      <!-- E-Visa VOA Extension -->
      <div class="bg-white border border-gray-200 rounded-xl shadow-md p-6 hover:shadow-lg transition flex flex-col justify-between">
        <img src="/images/voa.png" alt="Voa extention" class="rounded-xl mb-4 w-full h-40 object-cover">
        <h3 class="text-xl font-bold text-[#1e293b] mb-2">E - Visa VOA Extension</h3>
        <p class="text-sm text-gray-600 mb-2">A VOA extension permits an additional 30 days stay from visa expiration, after which another visa is required.</p>
        <ul class="list-disc pl-5 text-sm text-gray-700 mb-4">
          <li><strong>IDR 900,000</strong> – Regular 5 business days</li>
          <li><strong>IDR 1,500,000</strong> – Priority 3 business days</li>
        </ul>
        <div class="flex gap-2 mt-auto">
          <a href="/landingpage/extention/voaextention" class="px-4 py-2 bg-gray-200 text-sm rounded hover:bg-gray-300 transition">Learn More</a>
        <a x-data
        :href="'https://wa.me/628113858165?text=' + encodeURIComponent(`Hello, I would like to apply for the VOA extenntion.\nCould you please assist me with the application process? Thank you!`)"
        target="_blank"
        class="px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition">
        Apply
        </a>
        </div>
      </div>

      <!-- Single Entry Visa Extension -->
      <div class="bg-white border border-gray-200 rounded-xl shadow-md p-6 hover:shadow-lg transition flex flex-col justify-between">
        <img src="/images/single-entry.png" alt="Pre Invesment" class="rounded-xl mb-4 w-full h-40 object-cover">
        <h3 class="text-xl font-bold text-[#1e293b] mb-2">Single Entry Visa Extension</h3>
        <p class="text-sm text-gray-600 mb-2">Applies to Tourist, Business, Social, Humanitarian, or Journalistic visas. Max 2 extensions of 60 days each.</p>
        <ul class="list-disc pl-5 text-sm text-gray-700 mb-4">
          <li><strong>IDR 2,300,000</strong> – Regular 14 business days</li>
        </ul>
        <div class="flex gap-2 mt-auto">
          <a href="/landingpage/extention/singleentryextention" class="px-4 py-2 bg-gray-200 text-sm rounded hover:bg-gray-300 transition">Learn More</a>
        <a x-data
        :href="'https://wa.me/628113858165?text=' + encodeURIComponent(`Hello, I would like to apply for the Single Entry Visa Extension.\nCould you please assist me with the application process? Thank you!`)"
        target="_blank"
        class="px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition">
        Apply
        </a>
        </div>
      </div>

      <!-- Multiple Entry Pre-Invesment -->
      <div class="bg-white border border-gray-200 rounded-xl shadow-md p-6 hover:shadow-lg transition flex flex-col justify-between">
        <img src="/images/remoteworker-kitas.jpg" alt="Pre Invesment" class="rounded-xl mb-4 w-full h-40 object-cover">
        <h3 class="text-xl font-bold text-[#1e293b] mb-2">Multiple Entry Pre-Invesment</h3>
        <p class="text-sm text-gray-600 mb-2">Allows additional stay for pre-invesment. Maximize your visit time.</p>
        <ul class="list-disc pl-5 text-sm text-gray-700 mb-4">
          <li><strong>IDR 8,500,000</strong> – 14 business days (1 Years)</li>
          <li><strong>IDR 10,500,000</strong> – 14 business days (2 Years)</li>
        </ul>
        
        <div class="flex gap-2 mt-auto">
          <a href="/landingpage/extention/multipleentrypreinvesmentextention" class="px-4 py-2 bg-gray-200 text-sm rounded hover:bg-gray-300 transition">Learn More</a>
        <a x-data
        :href="'https://wa.me/628113858165?text=' + encodeURIComponent(`Hello, I would like to apply for the Multiple Entry Tourist & Business Visa Extension.\nCould you please assist me with the application process? Thank you!`)"
        target="_blank"
        class="px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition">
        Apply
        </a>
        </div>
      </div>

      <!-- Investor KITAS Extension -->
      <div class="bg-white border border-gray-200 rounded-xl shadow-md p-6 hover:shadow-lg transition flex flex-col justify-between">
        <img src="/images/investor-kitas.jpg" alt="Investor Kitas Extention" class="rounded-xl mb-4 w-full h-40 object-cover">
        <h3 class="text-xl font-bold text-[#1e293b] mb-2">Investor KITAS Extension</h3>
        <p class="text-sm text-gray-600 mb-2">Applicable for multiple entry visa and is valid for either 1 or 2 years. Can be extended accordingly.</p>

        <div class="flex gap-2 mt-auto">
        <a href="/landingpage/extention/investorkitasextention" class="px-4 py-2 bg-gray-200 text-sm rounded hover:bg-gray-300 transition">Learn More</a>
        <a x-data
        :href="'https://wa.me/628113858165?text=' + encodeURIComponent(`Hello, I would like to apply for the C - Single Entry Visa Extension.\nCould you please assist me with the application process? Thank you!`)"
        target="_blank"
        class="px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition">
        Apply
        </a>
        </div>
      </div>

      <!-- Working KITAS Extension -->
      <div class="bg-white border border-gray-200 rounded-xl shadow-md p-6 hover:shadow-lg transition flex flex-col justify-between">
        <img src="/images/working-kitas.jpg" alt="Working Kitas extention" class="rounded-xl mb-4 w-full h-40 object-cover">
        <h3 class="text-xl font-bold text-[#1e293b] mb-2">Working KITAS Extension</h3>
        <p class="text-sm text-gray-600 mb-2">A Working KITAS extension follows the initial KITAS validity period and can be renewed accordingly.</p>

        <div class="flex gap-2 mt-auto">
          <a href="/landingpage/extention/workingkitasextention" class="px-4 py-2 bg-gray-200 text-sm rounded hover:bg-gray-300 transition">Learn More</a>
        <a x-data
        :href="'https://wa.me/628113858165?text=' + encodeURIComponent(`Hello, I would like to apply for the working kitas extention.\nCould you please assist me with the application process? Thank you!`)"
        target="_blank"
        class="px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition">
        Apply
        </a>
        </div>
      </div>

      <!-- Family of Indonesian Citizen Extension -->
    <div class="bg-white border border-gray-200 rounded-xl shadow-md p-6 hover:shadow-lg transition flex flex-col justify-between">
    <img src="/images/familyindonesian-kitas.jpg" alt="Family of Indonesian Citizen" class="rounded-xl mb-4 w-full h-40 object-cover">
    <h3 class="text-xl font-bold text-[#1e293b] mb-2">Family of Indonesian Citizen Extension</h3>
    <p class="text-sm text-gray-600 mb-2">The Kitas for the Family of Indonesian citizens can be extended for one year.</p>
    
    <div class="flex gap-2 mt-auto">
        <a href="/landingpage/extention/familyindonesianextention" class="px-4 py-2 bg-gray-200 text-sm rounded hover:bg-gray-300 transition">Learn More</a>
        <a x-data
        :href="'https://wa.me/628113858165?text=' + encodeURIComponent(`Hello, I would like to apply for the Family of Indonesian Citizen Extension.\nCould you please assist me with the application process? Thank you!`)"
        target="_blank"
        class="px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition">
        Apply
        </a>
    </div>
    </div>

    <!-- Family of KITAS Holder Extension -->
    <div class="bg-white border border-gray-200 rounded-xl shadow-md p-6 hover:shadow-lg transition flex flex-col justify-between">
    <img src="/images/familyholder-kitas.jpg" alt="Family of KITAS Holder" class="rounded-xl mb-4 w-full h-40 object-cover">
    <h3 class="text-xl font-bold text-[#1e293b] mb-2">Family of KITAS holder Extension</h3>
    <p class="text-sm text-gray-600 mb-2">The Family of KITAS holder’s extension follows the sponsoring KITAS validity period.</p>
    
    <p class="text-sm text-gray-700 mb-1"><strong>1 year:</strong></p>
    <ul class="list-disc pl-5 text-sm text-gray-700 mb-2">
        <li><strong>IDR 10,000,000</strong> – Regular 14 business days</li>
    </ul>

    <p class="text-sm text-gray-700 mb-1"><strong>2 years:</strong></p>
    <ul class="list-disc pl-5 text-sm text-gray-700 mb-4">
        <li><strong>IDR 19,000,000</strong> – Regular 14 business days</li>
    </ul>

    <div class="flex gap-2 mt-auto">
        <a href="/landingpage/extention/familykitasextention" class="px-4 py-2 bg-gray-200 text-sm rounded hover:bg-gray-300 transition">Learn More</a>
        <a x-data
        :href="'https://wa.me/628113858165?text=' + encodeURIComponent(`Hello, I would like to apply for the Family of KITAS holder Extension.\nCould you please assist me with the application process? Thank you!`)"
        target="_blank"
        class="px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition">
        Apply
        </a>
    </div>
    </div>

    <!-- Retirement KITAS Extension -->
    <div class="bg-white border border-gray-200 rounded-xl shadow-md p-6 hover:shadow-lg transition flex flex-col justify-between">
    <img src="/images/retirement-kitas.jpg" alt="Retirement KITAS" class="rounded-xl mb-4 w-full h-40 object-cover">
    <h3 class="text-xl font-bold text-[#1e293b] mb-2">Retirement KITAS Extension</h3>
    <p class="text-sm text-gray-600 mb-2">A Retirement KITAS can be extended according to the initial KITAS validity period.</p>
    
    <p class="text-sm text-gray-700 mb-1"><strong>1 year:</strong></p>
    <ul class="list-disc pl-5 text-sm text-gray-700 mb-2">
        <li><strong>IDR 10,000,000</strong> – Regular 14 business days</li>
    </ul>

    <p class="text-sm text-gray-700 mb-1"><strong>2 years:</strong></p>
    <ul class="list-disc pl-5 text-sm text-gray-700 mb-4">
        <li><strong>IDR 15,000,000</strong> – Regular 14 business days</li>
    </ul>

    <div class="flex gap-2 mt-auto">
        <a href="/landingpage/extention/retirementkitasextention" class="px-4 py-2 bg-gray-200 text-sm rounded hover:bg-gray-300 transition">Learn More</a>
        <a x-data
        :href="'https://wa.me/628113858165?text=' + encodeURIComponent(`Hello, I would like to apply for the Retirement KITAS Extension.\nCould you please assist me with the application process? Thank you!`)"
        target="_blank"
        class="px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition">
        Apply
        </a>
    </div>
    </div>

    </div>
  </div>
</div>

  <!-- Footer -->
  <footer class="bg-gradient-to-tr from-sky-900 to-slate-800 text-white py-12 relative z-10">
  <div class="max-w-6xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 gap-6">

    <!-- Kiri: Logo dan Deskripsi -->
    <div>
      <img src="{{ asset('icons/logo.png') }}" alt="Logo Evisas" class="w-16 mb-4">
      <p class="text-sm text-gray-300 leading-relaxed">
        With a global network and deep understanding of immigration policies, we are committed to providing efficient and timely solutions.
      </p>
      <div class="flex space-x-4 mt-6">
        <a href="https://facebook.com" target="_blank" class="hover:scale-110 transition-transform duration-300">
          <img src="/icons/Facebook.png" alt="Facebook" class="w-6">
        </a>
        <a href="https://wa.me/628113858165" target="_blank" class="hover:scale-110 transition-transform duration-300">
          <img src="/icons/WhatsApp.png" alt="WhatsApp" class="w-6">
        </a>
        <a href="https://instagram.com" target="_blank" class="hover:scale-110 transition-transform duration-300">
          <img src="/icons/Instagram.png" alt="Instagram" class="w-6">
        </a>
      </div>
    </div>

    <!-- Kanan: Kontak -->
    <div>
      <h4 class="text-xl font-semibold mb-2 text-yellow-400">Evisas Contact</h4>
      <p class="text-sm text-gray-300 mt-4">
        Gunung Athena street no.38, Padangsambian, Denpasar Barat, Bali 80117
      </p>
      <p class="text-sm mt-4 text-gray-300">
        WhatsApp:
        <a href="https://wa.me/628113858165" class="text-blue-300 hover:underline">+62 811-3858-165</a>
      </p>
      <p class="text-sm mt-2 text-gray-300">
        Email:
        <a href="mailto:cs.evisasbali@gmail.com" class="text-blue-300 hover:underline">cs.evisasbali@gmail.com</a>
      </p>
    </div>
  </div>

  <!-- Copyright -->
  <div class="text-center text-xs mt-10 border-t border-blue-400 pt-4 text-gray-300">
    &copy; {{ date('Y') }} Evisas Indonesia. All rights reserved.
  </div>
</footer>
</body>

</html>
